#include <winsock2.h>
#include <iostream>
#include <cstring>
#include <limits.h>
#include <stdlib.h>
#include <sstream>
#include <thread>
#include <ws2tcpip.h>
#define true 1
using namespace std;

//�����
//����http������
void send_404(SOCKET s);
int create_socket(SOCKET s);
void accept_socket(sockaddr_in addrClient, string buffer);
void deal_socket(SOCKET s, string strb, string buffer);
int ThreadFun(SOCKET c, sockaddr_in addrClinet);
//ָ����̬���lib�ļ�
#pragma comment(lib,"ws2_32.lib")
string s1 = ".html";
string s2 = ".jpg";
int main() {
	WSADATA WD;
	if (WSAStartup(MAKEWORD(2, 2), &WD) != 0) {
		cout << "WSAStartup Error!" << WSAGetLastError() << endl;
		return 0;
	}
	//����TCP SOCKET
	SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s == INVALID_SOCKET) {
		cout << "Socket Error!" << WSAGetLastError() << endl;
		return 0;
	}
	int return_s = create_socket(s);
	while (true && return_s != -1) {
		//���߳�ѭ�����տͻ�������,�����غͿͻ���ͨѶ���׽���
		sockaddr_in addrClient;
		int len = sizeof(addrClient);
		SOCKET c = accept(return_s, (sockaddr*)&addrClient, &len);
		if (c != INVALID_SOCKET)
		{
			//�����̲߳��Ҵ�����clientͨѶ�׽���
			thread p(ThreadFun, c, addrClient);
			p.detach();
		}
		else
		{
			cout << "Accept Error!" << WSAGetLastError() << endl;
			return 0;
		}
	}
	//�ر��׽���
	closesocket(s);
	WSACleanup();
	return 0;
}

int create_socket(SOCKET s) {
	int ad = 0;
	char cd[20] = { '\0' };
	//��socket��һ��IP��ַ�Ͷ˿�
	sockaddr_in addr;
	addr.sin_family = AF_INET;//��ַ��
	cout << "please input socket font(0 means htons(80)):";
	cin >> ad;
	if (ad > 65535 || ad < 0) {
		cout << "Error input!" << endl;
		return 0;
	}
	addr.sin_port = ad == 0 ? htons(80) : htons(ad);//�˿�
	addr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);

	if (::bind(s, (sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR)
	{
		cout << "Bind Error!" << WSAGetLastError() << endl;
		return -1;
	}

	//����,5�����ȴ����г���
	if (listen(s, 5) == SOCKET_ERROR)
	{
		cout << "listen operation failed!" << endl;
		return -1;
	}
	return s;
}

int ThreadFun(SOCKET c, sockaddr_in addrClient) {

	//���ͽ�����Ϣ
	int ret = 0;
	//���տͻ�����Ϣ
	char buffer[2048] = { '\0' };
	ret = recv(c, buffer, sizeof(buffer), 0);
	//cout << buffer << endl;
	string stra, strb;
	stringstream http_txt(buffer);
	http_txt >> stra;
	http_txt >> strb;
	strb.erase(0, 1);
	if (stra == "GET")
	{
		string newbuf = buffer;
		accept_socket(addrClient, buffer);
		deal_socket(c, strb, newbuf);
	}
	return 0;
}

void accept_socket(sockaddr_in addrClient, string buffer) {
	cout << "PORT:" << ntohs(addrClient.sin_port) << endl;
	char str[20];
	inet_ntop(AF_INET, &addrClient.sin_addr, str, 20);
	cout << "IP:" << str << endl;
	string stra;
	int i = buffer.find("GET");
	int j = buffer.find("HTTP/1.1");
	stra = buffer.substr(i, j - i);
	stra += buffer.substr(j, 8);
	cout << stra << endl;
	return;
}

void deal_socket(SOCKET s, string strb, string buffer) {
	string path, send_buff;
	path = "html\\" + strb;
	send_buff = "HTTP/1.1 200 OK\r\n";
	send_buff += "Connection: keep-alive\r\n";
	string str1 = "Content-Type: text/html\r\n";
	string str2 = "Content-Type: image/jpg\r\n";
	if (strb.find(s1) != -1)
		send_buff += str1;
	else if (strb.find(s2) != -1)
		send_buff += str2;
	else {
		send_404(s);
		cout << "Files Error!\n" << endl;
		return;
	}
	FILE *fp;
	int error = fopen_s(&fp, path.c_str(), "rb");
	if (error) {
		if (fp)
			fclose(fp);
		send_404(s);
		cout << "No Such Files!\n" << endl;
		return;
	}
	fseek(fp, 0, SEEK_END);
	int length = ftell(fp);
	char *data = new char[length + 1];
	memset(data, 0, length + 1);
	fseek(fp, 0, SEEK_SET);
	send_buff += ("Content-Length: " + to_string(length));
	send_buff += "\r\n\r\n";
	fread(data, sizeof(char), length, fp);
	cout << send_buff;
	send(s, send_buff.c_str(), send_buff.length(), 0);
	send(s, data, length, 0);
	fclose(fp);
}

void send_404(SOCKET s)
{
	string send_buff = "<HTML><TITLE>Not Found</TITLE>\r\n";
	send_buff += "<BODY><h1 align='center'>404</h1><br/><h1 align='center'>file not found.</h1>\r\n";
	send_buff += "</BODY></HTML>\r\n";
	send(s, send_buff.c_str(), send_buff.length(), 0);
	closesocket(s);
}