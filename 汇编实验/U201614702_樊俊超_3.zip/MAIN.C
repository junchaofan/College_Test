#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define GOODS_NUM 4
#define GOODS_LEN 20
#ifdef __cplusplus
extern "C" {
#endif
	extern char AUTH, GA1, GB1;
	extern void FUN1(char *in_name);
	extern void FUN2(int shop_num, char *in_name, int a, int b, int c);
	extern void FUN3();
	extern void FUN4();
#ifdef __cplusplus
}
#endif



//�������:�̵�1��2��һ����Ʒ��ƫ�Ƶ�ַ���̵���Ʒ��Ŀ
void FUN5();
void printnum(int v)
{
	printf("%15d", v);
}

void printstr(char *s) {
	printf("%s", s);
}

int inputstr(char *s) {
	s[0] = 0;
	scanf("%s", s);
	int num = strlen(s);
	return num;
}

//�������:�̵�1��2��һ����Ʒ��ƫ�Ƶ�ַ���̵���Ʒ��Ŀ
void FUN5()
{
	int i = 0;
	char *goods1_num = &GA1 + 10;
	char *goods2_num = &GB1 + 10;
	printf("In SHOP1:\n");
	for (i = 0; i < GOODS_NUM; i++) {

		short *num1 = (short *)goods1_num;
		printf("Purc_Price:    %d  ", num1[0]);
		printf("Sales_Price:   %d  ", num1[1]);
		printf("Total_Stock:   %d\n", num1[2]);
		printf("Sales_Volumes: %d  ", num1[3]);
		printf("Ave_ProMargin: %d  \n\n", num1[4]);
		goods1_num += 20;
	}
	printf("In SHOP2:\n");
	for (i = 0; i < GOODS_NUM; i++) {
		short *num2 = (short *)goods2_num;
		printf("Purc_Price :   %d  ", num2[0]);
		printf("Sales_Price:   %d  ", num2[1]);
		printf("Total_Stock:   %d\n", num2[2]);
		printf("Sales_Volumes: %d  ", num2[3]);
		printf("Ranking:       %d  \n\n", num2[4]);
		goods2_num += 20;
	}
}

void main(void)
{
	int choice = 1;
	char IN_NAME[10] = "FANCHAO", IN_PWD[6] = "666";
	char in_name[12] = { 0, }, in_pwd[8] = { 0, };
	while (choice) {
		printf("Please input your name:");
		scanf("%s", in_name);
		getchar();
		printf("Please input your password:");
		scanf("%s", in_pwd);
		getchar();
		if (strcmp(in_name, IN_NAME))
		{
			AUTH = 0;
			choice = 6;
			printf("Login unsuccessfully!\n");
			break;
		}
		else if (!strcmp(in_name, IN_NAME) && !strcmp(in_pwd, IN_PWD))
		{
			AUTH = 1;
			printf("Login successfully!\n");
			break;
		}
		else
			printf("Failed to login,please try again!\n");
	}
	while (choice != 6) {
		printf("\t1=Info_Service  2=Info_modification  3=Average APR\n");
		printf("\t4=APR Sort      5=Traverse All       6=Exit\n");
		printf("Please input the number:");
		scanf("%d", &choice);
		getchar();
		switch (choice) {
		case 1: {
			printf("Press [ENTER] to return\n");
			printf("Name of the commodity to be querying:");
			scanf("%s", in_name);
			getchar();
			FUN1(in_name);
			break;
		}
		case 2: {
			printf("Press [ENTER] to return,[0] to jump\n");
			printf("Shop: [1]SHOP1   [2]SHOP2$");
			printf("Please input the number:");
			int shop_num = 0;
			int A, B, C;
			scanf("%d", &shop_num);
			getchar();
			if (!shop_num)
				break;
			printf("Name of the commodity to be querying:");
			scanf("%s", in_name);
			getchar();
			printf("Please the new number\n");
			printf("Purc_Price >>");
			scanf("%d", &A);
			getchar();
			if (!A)
				A = -1;
			printf("Sales_Price>>");
			scanf("%d", &B);
			getchar();
			if (!B)
				B = -1;
			printf("Total_Stock>>");
			scanf("%d", &C);
			getchar();
			if (!C)
				C = -1;
			FUN2(shop_num, in_name, A, B, C);
			break;
		}
		case 3: {
			FUN3();
			break;
		}
		case 4: {
			FUN4();
			break;
		}
		case 5: {
			FUN5();
			break;
		}
		case 6: {
			printf("SEE YOU!");
			break;
		}
		default: {
			printf("Please try again\n");
		}
		}
	}
}