package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class LoginController implements Initializable{
	@FXML
	private Button doctorlogin;
	@FXML
	private Button patientlogin;
	@FXML
	private Label titlelogin;
	
	@FXML void DoctorLogin_clicked()
	{
		System.out.println("��¼�У����Եȣ�");
		Stage tempStage = (Stage) doctorlogin.getScene().getWindow();
        tempStage.close();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Doctor.fxml"));
        AnchorPane root = new AnchorPane();
	    Scene myScene = new Scene(root);
	    try {
	       myScene.setRoot((Parent) loader.load());
	       Stage newStage = new Stage();
	       newStage.setTitle("ҽ�������ã�");
	       newStage.setScene(myScene);
	       newStage.show();
	    }catch (IOException ex) {
	    	ex.printStackTrace();
	    }
	}
	
	@FXML void PatientLogin_clicked()
	{
		System.out.println("��¼�У����Եȣ�");
	    Stage tempStage = (Stage) patientlogin.getScene().getWindow();
         tempStage.close();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Patient.fxml"));
        AnchorPane root = new AnchorPane();
	    Scene myScene = new Scene(root);
        try {
	       myScene.setRoot((Parent) loader.load());
	       Stage newStage = new Stage();
	       newStage.setTitle("���ߣ����ã�");
	       newStage.setScene(myScene);
	       newStage.show();
       }catch (IOException ex) {
    	  ex.printStackTrace();
       } 
   }
	

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}

}
