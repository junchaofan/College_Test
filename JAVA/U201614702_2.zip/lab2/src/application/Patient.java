//����Patient�ඨ������ģ�ͣ��ṩ���˵���Ϣ
package application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Patient {
	private final StringProperty GHBH;
	private final StringProperty BRMC;
	private final StringProperty RQSJ;
	private final StringProperty HZ;
	
	public Patient(String GHBH,String BRMC,String RQSJ, String HZ)
	{
		this.GHBH = new SimpleStringProperty(GHBH);
		this.BRMC = new SimpleStringProperty(BRMC);
		this.RQSJ = new SimpleStringProperty(RQSJ);
		this.HZ = new SimpleStringProperty(HZ);
	}

	public String GHBHProperty() {
		return GHBH.get();
	}
	public String BRMCProperty() {
		return BRMC.get();
	}
	public String RQSJProperty()
	{
		return RQSJ.get();
	}	
	public String HZProperty()
	{
		return HZ.get();
	}
}
