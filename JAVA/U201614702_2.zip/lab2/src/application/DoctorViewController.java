package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class DoctorViewController implements Initializable{
	
	@FXML private Label welcomeLabel;
	@FXML private TabPane Tabpane;
	@FXML private Tab TabPatient;
	@FXML private Tab TabIncome;
    private ObservableList<Patient> PatientData = FXCollections.observableArrayList();
	@FXML private TableView<Patient> patientTable;
	@FXML private TableColumn<Patient, String> GHBHColumn;
	@FXML private TableColumn<Patient, String> BRMCColumn;
	@FXML private TableColumn<Patient, String> RQSJColumn;
	@FXML private TableColumn<Patient, String> HZColumn;
	
	private ObservableList<Income> IncomeData = FXCollections.observableArrayList();
	@FXML private TableView<Income> incomeTable;
	@FXML private TableColumn<Income, String> KSMCColumn;
	@FXML private TableColumn<Income, String> YSBHColumn;
	@FXML private TableColumn<Income, String> YSMCColumn;
	@FXML private TableColumn<Income, String> HZLBColumn;
	@FXML private TableColumn<Income, String> GHRCColumn;
	@FXML private TableColumn<Income, String> SRHJColumn;
	@FXML private DatePicker DateStart;
	@FXML private DatePicker DateEnd;
	@FXML private Button Reback;
	@FXML private Button Exit;
	@FXML private Button Load;
	
	@Override
    public void initialize(URL location, ResourceBundle resources) {
		GHBHColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().GHBHProperty()));
		BRMCColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().BRMCProperty()));
		RQSJColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().RQSJProperty()));
		HZColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().HZProperty()));
		KSMCColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().KSMCProperty()));
		YSBHColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().YSBHProperty()));
		YSMCColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().YSMCProperty()));
		HZLBColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().HZLBProperty()));
		GHRCColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().GHRCProperty()));
		SRHJColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().SRHJProperty()));
		Welcome();
		showPatientInfo();
		showIncomeInfo();
    }	
	
	void Welcome() {
	//�������ݿ�
	   MySql first = new MySql();
	   Connection second = first.create();
	   if(second == null)
	   {
		   JOptionPane.showMessageDialog(null, "�������ݿ�ʧ�ܣ�");
		   return;
	   }
	//�������ݿ�
	    PreparedStatement state = null;
		ResultSet rs = null;
		String DocName = "";
		String sql="SELECT * from t_ksys where YSBH = ?";
		try {
			state=(PreparedStatement) second.prepareStatement(sql);
			state.setString(1, DoctorController.DoctorID);
			rs = state.executeQuery();
			rs.next();
			DocName = rs.getString("YSMC").trim();
			String wel = "��ӭ " + DocName + " ҽ��!";	
			welcomeLabel.setText(wel);   
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	//�ر����ݿ�����
		try {
			state.close();
			second.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	
	@FXML
	void showPatientInfo(){
		PatientData.clear();
		MySql first = new MySql();
		Connection second = first.create();
		if(second == null)
		{
			JOptionPane.showMessageDialog(null, "�������ݿ�ʧ�ܣ�");
			return;
		}
		PreparedStatement state = null;
		ResultSet rs = null;
		String sql="SELECT DISTINCT GHBH,BRMC,RQSJ,SFZJ FROM t_ghxx,t_hzxx,t_brxx "
				+ "WHERE t_ghxx.BRBH=t_brxx.BRBH AND t_ghxx.HZBH=t_hzxx.HZBH "
				+ "AND RQSJ >= ? AND RQSJ <= ? AND YSBH = ? "
				+ "ORDER BY RQSJ ASC,BRMC ASC,GHBH ASC,SFZJ DESC";
		try {
			state=second.prepareStatement(sql);
			if(DateStart.getValue()==null) {
				DateStart.setValue(LocalDate.now());
			}
			if(DateEnd.getValue()==null) {
				DateEnd.setValue(LocalDate.now());
			}
			state.setString(1, DateStart.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))+" 00:00:00");
			state.setString(2, DateEnd.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))+" 23:59:59");
			state.setString(3, DoctorController.DoctorID);
			rs = state.executeQuery();
			String GHStr = null,BRStr = null,SJStr = null,HZStr = null;
			while(rs.next()) {
				GHStr = rs.getString("GHBH").trim();
				BRStr = rs.getString("BRMC").trim();
				SJStr = rs.getString("RQSJ").trim();
				HZStr = rs.getInt("SFZJ") == 1 ? "ר�Һ�":"��ͨ��";
				PatientData.add(new Patient(GHStr,BRStr,SJStr,HZStr));
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		patientTable.setItems(PatientData);
		try {
			state.close();
			second.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
    
	@FXML
	public void showIncomeInfo(){
		IncomeData.clear();
		MySql first = new MySql();
		Connection second = first.create();
		if(second == null)
		{
			JOptionPane.showMessageDialog(null, "�������ݿ�ʧ�ܣ�");
			return;
		}
		PreparedStatement state = null;
		ResultSet rs = null;
		String sql="SELECT KSSET.KSMC,YSSET.YSBH,YSSET.YSMC,HZSET.SFZJ,COUNT(GHSET.GHRC),SUM(GHSET.GHFY)"
				+ " FROM (SELECT * FROM t_ghxx WHERE RQSJ >= ? AND RQSJ <= ?) AS GHSET INNER JOIN"
				+ "	(SELECT HZBH,SFZJ FROM t_hzxx) AS HZSET ON (GHSET.HZBH=HZSET.HZBH) INNER JOIN"
				+ "	(SELECT YSBH,YSMC,KSBH FROM t_ksys) AS YSSET ON (GHSET.YSBH=YSSET.YSBH) INNER JOIN "
				+ " (SELECT KSBH,KSMC FROM t_ksxx) AS KSSET ON (KSSET.KSBH=YSSET.KSBH)"
				+ "GROUP BY GHSET.YSBH,HZSET.SFZJ "
				+ "ORDER BY GHSET.YSBH ASC,HZSET.SFZJ DESC	";
		try {
			if(DateStart.getValue()==null) {
				DateStart.setValue(LocalDate.now());
			}
			if(DateEnd.getValue()==null) {
				DateEnd.setValue(LocalDate.now());
			}
			state=second.prepareStatement(sql);
			state.setString(1, DateStart.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))+" 00:00:00");
			state.setString(2, DateEnd.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))+" 23:59:59");
			rs = state.executeQuery();
			String KSStr = null,YSStr = null,MCStr = null,HZStr = null,GHStr = null,SRStr = null;
			while(rs.next()) {
				
				KSStr = rs.getString("KSMC").trim();
				YSStr = rs.getString("YSSET.YSBH").trim();
				MCStr = rs.getString("YSMC").trim();
				HZStr = rs.getInt("SFZJ") == 1 ? "ר�Һ�":"��ͨ��";
				GHStr = rs.getString("COUNT(GHSET.GHRC)").trim();
				SRStr = rs.getString("SUM(GHSET.GHFY)").trim();
				IncomeData.add(new Income(KSStr,YSStr,MCStr,HZStr,GHStr,SRStr));
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		incomeTable.setItems(IncomeData);
		try {
			state.close();
			second.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	
	@FXML
	public void Load_clicked() {
		if(Tabpane.getSelectionModel().getSelectedItem()==TabPatient) {
			showPatientInfo();
		}else{
			showIncomeInfo();
		}
	}
		
	@FXML
	public void exit_clicked(){
		System.exit(0);
	}
	
	@FXML
	public void reback_clicked() {
		Stage tempStage = (Stage) Reback.getScene().getWindow();
        tempStage.close();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
        AnchorPane root = new AnchorPane();
	    Scene myScene = new Scene(root);
       try {
	       myScene.setRoot((Parent) loader.load());
	       Stage newStage = new Stage();
	       newStage.setTitle("����ҽԺ�Һ�ϵͳ");
	       newStage.setScene(myScene);
	       newStage.show();
      }catch (IOException ex) {
    	  ex.printStackTrace();
      } 
	}
	
	@FXML
	public void judge_clicked() {
		String date1=DateEnd.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		String date2=DateStart.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		if(date1.compareTo(date2)<0) {
			JOptionPane.showMessageDialog(null, "ʱ���߼�����Ĭ�ϳ�ʼʱ��Ϊ��ֹʱ�䣡");
			DateStart.setValue(DateEnd.getValue());
			Load_clicked();
		}
		
	}
}
