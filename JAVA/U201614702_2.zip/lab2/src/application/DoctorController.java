package application;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import javax.swing.JOptionPane;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.control.PasswordField;

public class DoctorController implements Initializable{
	static String DoctorID;
	@FXML
	private Button Login;
	@FXML
	private Button Exit;
	@FXML
	private Button BackInput;
	@FXML
	private TextField UserInput;
	@FXML
	private PasswordField PwdInput;
	@FXML
	public void onEnter() {
		login_clicked();
	}
	
	@FXML
	public void login_clicked(){
		System.out.println("��¼�У�ҽ��"+UserInput.getText()+"���Եȣ�");
		//Ԥ���жϲ����������ݿ�
		if(UserInput.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�û��˺Ų���Ϊ�գ�");
			return;
		}
		if(PwdInput.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�û����벻��Ϊ�գ�");
			return;
		}
		MySql first = new MySql();
		Connection second = first.create();
		if(second==null) {
			JOptionPane.showMessageDialog(null, "�������ݿ�ʧ�ܣ�");
			return;
		}
		//�������ݿ�
		PreparedStatement state=null;
		ResultSet rs=null;
		String Pwd = "";
		try {
			String sql="select DLKL from t_ksys where YSBH = ?";
			state = (PreparedStatement) second.prepareStatement(sql);
			state.setString(1,UserInput.getText());
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			JOptionPane.showMessageDialog(null,"δ�ҵ���Ϣ");
			e.printStackTrace();
		}
		try {
			rs = state.executeQuery();
			if(rs==null) {
				JOptionPane.showMessageDialog(null,"���˻���δע�ᣡ");
			}else {
				rs.next();
			}
			Pwd=rs.getString("DLKL").trim();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		if(Pwd.equals(PwdInput.getText())){
			DoctorID=UserInput.getText().trim();
			//����ҽ����Ϣ��ĵ�½����
			try {
				Date newtime = new Date();
				SimpleDateFormat newdate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String sql2="update t_ksys set DLRQ = ? where YSBH = ?";
				state = (PreparedStatement) second.prepareStatement(sql2);
				state.setString(1,newdate.format(newtime));
				state.setString(2,UserInput.getText());
			}catch(SQLException e){
				e.printStackTrace();
			}
			
			try {
				state.executeUpdate();
			} catch (SQLException e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
			try {
				state.close();
				second.close();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			//ִ����һģ��Һ�
			Stage tempStage = (Stage) Login.getScene().getWindow();
	        tempStage.close();
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("DoctorView.fxml"));
	        AnchorPane root = new AnchorPane();
		    Scene myScene = new Scene(root);
		    try {
		       myScene.setRoot((Parent) loader.load());
		       Stage newStage = new Stage();
		       newStage.setTitle("ҽ����Ϣ��������");
		       newStage.setScene(myScene);
		       newStage.show();
		    }catch (IOException e) {
		    	e.printStackTrace();
		    } 
		}else {
			JOptionPane.showMessageDialog(null, "��½ʧ�ܣ�������˺Ŵ���");
		}
		return;
	}
	
	@FXML
	public void exit_clicked(){
		System.exit(0);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}
	
	@FXML
	public void reback_clicked() {
		Stage tempStage = (Stage) BackInput.getScene().getWindow();
        tempStage.close();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
        AnchorPane root = new AnchorPane();
	    Scene myScene = new Scene(root);
       try {
	       myScene.setRoot((Parent) loader.load());
	       Stage newStage = new Stage();
	       newStage.setTitle("����ҽԺ�Һ�ϵͳ");
	       newStage.setScene(myScene);
	       newStage.show();
      }catch (IOException ex) {
    	  ex.printStackTrace();
      } 
	}
}
