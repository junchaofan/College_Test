package application;
import java.sql.Connection;
import java.sql.DriverManager;

/*���ӵ�MySQL���ݿ�*/
public class MySql {
	public Connection create()
	{
		Connection myCon = null;
		try {
			myCon =(Connection) DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/mysql?characterEncoding=utf8&useSSL=false&serverTimezone=UTC","root","306015");
			
			if(myCon != null)
			{
				System.out.println("Successfully connected!");
			}
			return myCon;
		}catch(Exception e)
		{
			System.out.print("Connection failed!");
		}
		return myCon;
	}
}