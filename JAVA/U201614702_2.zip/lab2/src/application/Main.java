package application;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

/*�������*/
public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        try {
            // Read file fxml and draw interface.
        	MySql first = new MySql();
        	first.create();
        	FXMLLoader loader = new FXMLLoader(
      	          getClass().getResource("Login.fxml")
      	        );
        	AnchorPane root = new AnchorPane();
        	Scene myScene = new Scene(root);
      	    myScene.setRoot((Parent) loader.load());
            primaryStage.setScene(myScene);
            primaryStage.setTitle("����ҽԺ�Һ�ϵͳ");
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}