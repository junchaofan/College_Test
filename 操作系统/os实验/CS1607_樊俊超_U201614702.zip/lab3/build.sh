gcc -o writebuf writebuf.c head.h
gcc -o readbuf readbuf.c head.h
gcc -o main main.c head.h
./main
